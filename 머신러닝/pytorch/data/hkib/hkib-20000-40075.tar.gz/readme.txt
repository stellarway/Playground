

   한국일보-20000/한국일보-40075 문서범주화 실험문서집합

HKIB-20000/HKIB-40075 Korean Text Categorization Test Collections




     다음 문서에 보다 상세한 설명이 수록되어 있습니다.



HTML: http://www.kristalinfo.com/TestCollections/readme_hkib.html

 PDF: http://www.kristalinfo.com/TestCollections/readme_hkib.pdf


